/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


import java.util.Scanner;

/**
 *
 * Mirko Marcis 4infd
 * esercizio che stampa quante volte la lettera a si ripete in una stringa di lettere
 */
public class stringhe {
    

    
    public static void main(String[] args) {
        //creazione dell'oggetto che richiamerà la funzione delle ricorrenze
        RicorrenzaA stampa = new RicorrenzaA();
        stampa.ricorrenzaA(); //richiamo della funzione ricorrenzaA
        
    }
    
}
